package com.example.a22_09_2020;

public interface IActivity {
    public void setupUI();
    public void setupActions();
}
