package models;

import java.util.ArrayList;
import java.util.HashMap;

public class Book {
    private int id;
    private String name;
    private String author;
    private int rate;
    private String description;

    public Book(int id, String name, String author, int rate, String description) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.rate = rate;
        this.description = description;
    }
    /*
    public static Book createBookFromHashMap(HashMap<String, Object> hashMap) {
        return
    }
    */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public static ArrayList<Book> generateFakeBooks() {
        ArrayList<Book> books = new ArrayList<>();
        books.add(new Book(1,"Lap trinh C", "Nguyen Van A", 3, "Day la quteb CCC"));
        books.add(new Book(2,"Android Koptlin", "bu ge wlkds ", 1, "Day la quteb CCC"));
        books.add(new Book(3,"C# lap trinh", "Alelne", 3, "Day la quteb CCC"));
        books.add(new Book(4,"Kotlin", "Joe je", 5, "Day la quteb CCC"));
        books.add(new Book(5,"ReactJS", "rrttr", 3, "Day la quteb CCC"));
        books.add(new Book(6,"Flutter", "sewerw", 5, "Day la quteb CCC"));
        books.add(new Book(7,"Dotnet Core", "weere", 2, "Day la quteb CCC"));
        books.add(new Book(8,"ios", "eeewwrwer", 1, "Day la quteb CCC"));
        return books;
    }
}
